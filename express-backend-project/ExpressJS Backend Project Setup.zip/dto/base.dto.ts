// Define a generic DTO type
export default interface BaseDTO {
    // Define common properties or leave it empty based on your needs
}