import express from 'express';
import {Request, Response, NextFunction, Router} from 'express';
import  GlobalController from './../controllers/global/global.controller';

const router : Router = express.Router();
const globalController = new GlobalController();

/* GET home page. */
router.get('/', globalController.homePage);
router.get('/token', globalController.generateToken);

module.exports = router;
